<?php

namespace App\Http\Controllers\Frontend;

use App\Models\Bundle;
use App\Http\Controllers\Controller;

class BundleController extends Controller
{
    public function index()
    {
        $bundles = \App\Models\Bundle::with('products')->get();
        return view('frontend.bundles.index', compact('bundles'));
    }

    public function show(\App\Models\Bundle $bundle)
    {
        $bundle->load('products');
        return view('frontend.bundles.show', compact('bundle'));
    }
}
