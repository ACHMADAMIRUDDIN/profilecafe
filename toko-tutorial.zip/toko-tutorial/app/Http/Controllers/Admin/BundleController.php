<?php

namespace App\Http\Controllers\Admin;

use App\Models\Bundle;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Http\Controllers\Controller;

class BundleController extends Controller
{
    public function index()
    {
        $bundles = Bundle::with('products')->get();
        return view('admin.bundles.index', compact('bundles'));
    }

    public function create()
    {
        $products = Product::all();
        return view('admin.bundles.create', compact('products'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'price' => 'required|numeric',
            'products' => 'required|array',
            'products.*' => 'exists:products,id',
            'qty.*' => 'required|integer|min:1'
        ]);
        $bundle = Bundle::create([
            'name' => $request->name,
            'slug' => Str::slug($request->name),
            'price' => $request->price,
            'description' => $request->description,
        ]);
        foreach ($request->products as $i => $productId) {
            $bundle->items()->create([
                'product_id' => $productId,
                'qty' => $request->qty[$i] ?? 1,
            ]);
        }
        return redirect()->route('admin.bundles.index')->with(['message' => 'Bundle created!', 'alert-type' => 'success']);
    }

    public function edit(Bundle $bundle)
    {
        $products = Product::all();
        $bundle->load('items');
        return view('admin.bundles.create', compact('bundle', 'products'));
    }

    public function update(Request $request, Bundle $bundle)
    {
        $request->validate([
            'name' => 'required',
            'price' => 'required|numeric',
            'products' => 'required|array',
            'products.*' => 'exists:products,id',
            'qty.*' => 'required|integer|min:1'
        ]);
        $bundle->update([
            'name' => $request->name,
            'slug' => Str::slug($request->name),
            'price' => $request->price,
            'description' => $request->description,
        ]);
        $bundle->items()->delete();
        foreach ($request->products as $i => $productId) {
            $bundle->items()->create([
                'product_id' => $productId,
                'qty' => $request->qty[$i] ?? 1,
            ]);
        }
        return redirect()->route('admin.bundles.index')->with(['message' => 'Bundle updated!', 'alert-type' => 'info']);
    }

    public function destroy(Bundle $bundle)
    {
        $bundle->delete();
        return redirect()->route('admin.bundles.index')->with(['message' => 'Bundle deleted!', 'alert-type' => 'danger']);
    }
}
