<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Order;
use App\Models\User;

class DashboardController extends Controller
{
    public function index()
    {
        $totalOrders = Order::count();
        $totalOrdersCompleted = Order::where('status', Order::COMPLETED)->count();
        $totalCustomers = User::where('is_admin','0')->count();
        $totalProducts = Product::count();

        return view('admin.dashboard', compact(
            'totalProducts',
            'totalOrders',
            'totalOrdersCompleted',
            'totalCustomers'
        ));
    }
}
