<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use App\Models\Category;


class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
        $categories = Category::parentCategories()
        ->orderBy('name', 'asc')
        ->get();

        view()->share('categories', $categories);
    }

    public function showLoginForm()
	{
		if (view()->exists('auth.authenticate')) {
			return view('auth.authenticate');
		}

		return view('frontend.auth.login');
	}

    public function authenticated($request, $user)
    {
        if ($user->is_admin == 1) {
            return redirect()->route('admin.dashboard');
        }
    }

    protected function sendFailedLoginResponse(Request $request)
    {
        return redirect()->route('login')->withInput($request->only($this->username(), 'remember'))
        ->withErrors([
            $this->username() => trans('auth.failed'),
        ]);

    }

}
