<?php

namespace Database\Seeders;

use App\Models\Product;
use Illuminate\Database\Seeder;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $csvFile = storage_path('data/products.csv');
        if (file_exists($csvFile)) {
            $file = fopen($csvFile, 'r');
            $header = fgetcsv($file);
            $products = 0;
            while (($row = fgetcsv($file)) !== false) {
                $data = array_combine($header, $row);
                $slug = Str::slug($data['Description'], '-');
                $product = Product::updateOrCreate(
                    ['sku' => $data['StockCode']],
                    [
                        'sku' => $data['StockCode'],
                        'type' => 'simple',
                        'name' => $data['Description'],
                        'slug' => $slug,
                        'price' => $data['UnitPrice'] * 16700,
                        'weight' => rand(100, 500) / 100, // Random weight between 1.00 and 5.00 kg
                        'length' => rand(10, 50), // Random length between 10 and 50 cm
                        'width' => rand(10, 50), // Random width between 10 and 50 cm
                        'height' => rand(10, 50), // Random height between 10 and 50 cm
                        'short_description' => $data['Description'],
                        'description' => $data['Description'],
                        'status' => 1,
                        'user_id' => 1
                    ]
                );
                $product->productInventory()->updateOrCreate(
                    ['product_id' => $product->id],
                    [
                        'qty' => rand(1, 100), // Random quantity between 1 and 100
                    ]
                );
                $categoryCount = rand(1, 3);
                $categoryIds = [];
                for ($i = 0; $i < $categoryCount; $i++) {
                    $categoryIds[] = rand(1, 30);
                }
                $categoryIds = array_unique($categoryIds);
                $product->categories()->sync($categoryIds);
                $this->command->info('Product created: ' . $product->name . ' with SKU: ' . $product->sku);
                $this->command->info('Count of products: ' . ++$products);
            }
            fclose($file);
        }

        // Product::create([
        //     'sku' => 'produk-sku',
        //     'type' => 'configurable',
        //     'name' => 'nama produk',
        //     'slug' => 'nama-produk',
        //     'user_id' => 1
        // ]);
        // Product::create([
        //     'sku' => 'product-sku-simple',
        //     'type' => 'simple',
        //     'name' => 'nama produk simple',
        //     'slug' => 'nama-produk-simple',
        //     'user_id' => 1
        // ]);
    }
}
