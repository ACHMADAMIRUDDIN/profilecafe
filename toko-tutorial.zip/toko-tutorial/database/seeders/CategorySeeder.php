<?php

namespace Database\Seeders;

use App\Models\Category;
use Carbon\Carbon;
use Illuminate\Database\Seeder;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $now = Carbon::now();

        $categories = [
            ['id' => 1, 'name' => 'Elektronik', 'slug' => 'elektronik', 'parent_id' => null],
            ['id' => 2, 'name' => 'Handphone', 'slug' => 'handphone', 'parent_id' => 1],
            ['id' => 3, 'name' => 'Laptop', 'slug' => 'laptop', 'parent_id' => 1],
            ['id' => 4, 'name' => 'Kamera', 'slug' => 'kamera', 'parent_id' => 1],
            ['id' => 5, 'name' => 'Fashion', 'slug' => 'fashion', 'parent_id' => null],
            ['id' => 6, 'name' => 'Pakaian Pria', 'slug' => 'pakaian-pria', 'parent_id' => 5],
            ['id' => 7, 'name' => 'Pakaian Wanita', 'slug' => 'pakaian-wanita', 'parent_id' => 5],
            ['id' => 8, 'name' => 'Sepatu', 'slug' => 'sepatu', 'parent_id' => 5],
            ['id' => 9, 'name' => 'Rumah & Dapur', 'slug' => 'rumah-dapur', 'parent_id' => null],
            ['id' => 10, 'name' => 'Perabotan', 'slug' => 'perabotan', 'parent_id' => 9],
            ['id' => 11, 'name' => 'Peralatan Dapur', 'slug' => 'peralatan-dapur', 'parent_id' => 9],
            ['id' => 12, 'name' => 'Perlengkapan Tidur', 'slug' => 'perlengkapan-tidur', 'parent_id' => 9],
            ['id' => 13, 'name' => 'Kecantikan & Perawatan', 'slug' => 'kecantikan-perawatan', 'parent_id' => null],
            ['id' => 14, 'name' => 'Makeup', 'slug' => 'makeup', 'parent_id' => 13],
            ['id' => 15, 'name' => 'Perawatan Kulit', 'slug' => 'perawatan-kulit', 'parent_id' => 13],
            ['id' => 16, 'name' => 'Perawatan Rambut', 'slug' => 'perawatan-rambut', 'parent_id' => 13],
            ['id' => 17, 'name' => 'Olahraga & Luar Ruangan', 'slug' => 'olahraga-luar-ruangan', 'parent_id' => null],
            ['id' => 18, 'name' => 'Fitness & Gym', 'slug' => 'fitness-gym', 'parent_id' => 17],
            ['id' => 19, 'name' => 'Camping & Hiking', 'slug' => 'camping-hiking', 'parent_id' => 17],
            ['id' => 20, 'name' => 'Sepeda', 'slug' => 'sepeda', 'parent_id' => 17],
            ['id' => 21, 'name' => 'Mainan & Permainan', 'slug' => 'mainan-permainan', 'parent_id' => null],
            ['id' => 22, 'name' => 'Mainan Edukasi', 'slug' => 'mainan-edukasi', 'parent_id' => 21],
            ['id' => 23, 'name' => 'Permainan Papan', 'slug' => 'permainan-papan', 'parent_id' => 21],
            ['id' => 24, 'name' => 'Action Figure', 'slug' => 'action-figure', 'parent_id' => 21],
            ['id' => 25, 'name' => 'Buku', 'slug' => 'buku', 'parent_id' => null],
            ['id' => 26, 'name' => 'Fiksi', 'slug' => 'fiksi', 'parent_id' => 25],
            ['id' => 27, 'name' => 'Non-Fiksi', 'slug' => 'non-fiksi', 'parent_id' => 25],
            ['id' => 28, 'name' => 'Buku Anak', 'slug' => 'buku-anak', 'parent_id' => 25],
            ['id' => 29, 'name' => 'Otomotif', 'slug' => 'otomotif', 'parent_id' => null],
            ['id' => 30, 'name' => 'Aksesori Mobil', 'slug' => 'aksesori-mobil', 'parent_id' => 29],
        ];

        foreach ($categories as $category) {
            Category::updateOrCreate(
                ['id' => $category['id']],
                $category
            );
        }
    }
}
