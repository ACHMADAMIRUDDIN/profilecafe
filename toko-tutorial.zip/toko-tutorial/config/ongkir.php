<?php

return [
    'api_key' => env('RAJAONGKIR_API_KEY', null),
    'base_url' => env('RAJAONGKIR_BASE_URL', null),
    'origin' => env('RAJAONGKIR_ORIGIN', null),
];