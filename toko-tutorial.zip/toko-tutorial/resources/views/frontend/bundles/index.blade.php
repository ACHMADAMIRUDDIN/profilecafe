@extends('frontend.layout')
@section('content')
<div class="container pt-5">
    <h2>Bundle Produk</h2>
    <div class="row">
        @foreach($bundles as $bundle)
        <div class="col-md-4">
            <div class="card mb-3">
                <div class="card-body">
                    <h4>{{ $bundle->name }}</h4>
                    <p>Rp{{ number_format($bundle->price,0,",",".") }}</p>
                    <ul>
                        @foreach($bundle->products as $product)
                            <li>{{ $product->name }} (x{{ $product->pivot->qty }})</li>
                        @endforeach
                    </ul>
                    <a href="{{ route('bundle.detail', $bundle) }}" class="btn btn-info btn-sm">Lihat Detail</a>
                    <form action="{{ route('carts.add_bundle') }}" method="POST" style="display:inline">
                        @csrf
                        <input type="hidden" name="bundle_id" value="{{ $bundle->id }}">
                        <button class="btn btn-success btn-sm">Tambah ke Keranjang</button>
                    </form>
                </div>
            </div>
        </div>
        @endforeach
    </div>
</div>
@endsection
