@extends('frontend.layout')
@section('content')
<div class="container pt-5">
    <h2>{{ $bundle->name }}</h2>
    <p>Harga Paket: Rp{{ number_format($bundle->price,0,",",".") }}</p>
    <p>{{ $bundle->description }}</p>
    <ul>
        @foreach($bundle->products as $product)
            <li>{{ $product->name }} (x{{ $product->pivot->qty }})</li>
        @endforeach
    </ul>
    <form action="{{ route('carts.add_bundle') }}" method="POST">
        @csrf
        <input type="hidden" name="bundle_id" value="{{ $bundle->id }}">
        <button class="btn btn-success">Tambah ke Keranjang</button>
    </form>
</div>
@endsection
