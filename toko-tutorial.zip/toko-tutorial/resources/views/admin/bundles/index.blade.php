@extends('layouts.app')
@section('content')
<div class="container">
    <a href="{{ route('admin.bundles.create') }}" class="btn btn-success mb-3">Tambah Bundle</a>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Nama Bundle</th>
                <th>Harga Paket</th>
                <th>Produk</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            @foreach($bundles as $bundle)
            <tr>
                <td>{{ $bundle->name }}</td>
                <td>Rp{{ number_format($bundle->price,0,",",".") }}</td>
                <td>
                    <ul>
                        @foreach($bundle->products as $product)
                            <li>{{ $product->name }} (x{{ $product->pivot->qty }})</li>
                        @endforeach
                    </ul>
                </td>
                <td>
                    <a href="{{ route('admin.bundles.edit', $bundle) }}" class="btn btn-info btn-sm">Edit</a>
                    <form action="{{ route('admin.bundles.destroy', $bundle) }}" method="POST" style="display:inline">
                        @csrf @method('DELETE')
                        <button class="btn btn-danger btn-sm" onclick="return confirm('Hapus bundle?')">Hapus</button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
