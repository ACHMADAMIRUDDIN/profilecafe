@extends('layouts.app')
@section('content')
<div class="container">
    <form action="{{ isset($bundle) ? route('admin.bundles.update', $bundle) : route('admin.bundles.store') }}" method="POST">
        @csrf
        @if(isset($bundle))
            @method('PUT')
        @endif
        <div class="form-group">
            <label>Nama Bundle</label>
            <input type="text" name="name" class="form-control" required value="{{ $bundle->name ?? '' }}">
        </div>
        <div class="form-group">
            <label>Harga Paket</label>
            <input type="number" name="price" class="form-control" required value="{{ $bundle->price ?? '' }}">
        </div>
        <div class="form-group">
            <label>Deskripsi</label>
            <textarea name="description" class="form-control">{{ $bundle->description ?? '' }}</textarea>
        </div>
        <div class="form-group">
            <label>Pilih Produk</label>
            <div id="bundle-products">
                @foreach($products as $product)
                    @php
                        $checked = isset($bundle) && $bundle->items->where('product_id', $product->id)->first();
                        $qty = $checked ? $bundle->items->where('product_id', $product->id)->first()->qty : 1;
                    @endphp
                    <div>
                        <input type="checkbox" name="products[]" value="{{ $product->id }}" {{ $checked ? 'checked' : '' }}> {{ $product->name }}
                        <input type="number" name="qty[]" value="{{ $qty }}" min="1" style="width:60px" placeholder="Qty">
                    </div>
                @endforeach
            </div>
        </div>
        <button class="btn btn-primary">Simpan</button>
    </form>
</div>
@endsection
